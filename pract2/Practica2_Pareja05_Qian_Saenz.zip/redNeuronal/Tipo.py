from enum import Enum

class Tipo(Enum):
    DIRECTA = 1
    SESGOIGUAL = 2
    SESGO = 3
    MCCULLOCH = 4
    PERCEPTRON = 5
    ADALINE = 6
    SIGMOIDE = 7
    SALIDA = 8