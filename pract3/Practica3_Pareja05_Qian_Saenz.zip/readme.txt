Neuro_P3_enunciado_2021_2022.ipynb es el fichero principal.

Neuro_P3_normal y Neuro_P3_one_hot son 2 ficheros para intentar buscar la mejor manera para incrementar el valor de F1-Score.

Neuro_P3_onehot_entropy y Neuro_P3_onehot_mse son 2 ficheros que realizan exclusivamente para RandomSearch.